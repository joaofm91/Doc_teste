def multiply_nums(num1, num2):
    """This method will be used to multiply two numbers

        :param int num1: The first number
        :param int num2: The second number

        :returns: The product of two numbers

        :rtype: int
    """
    answer = num1 * num2
    return answer
