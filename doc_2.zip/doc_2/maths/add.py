def add_nums(num1, num2):
    """This method will be used to add two numbers

        :param int num1: The first number
        :param int num2: The second number

        :returns: The sum of two numbers

        :rtype: int
    """
    answer = num1 + num2
    return answer
