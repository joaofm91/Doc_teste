.. Teste documentation master file, created by
   sphinx-quickstart on Mon Sep 25 15:38:49 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Teste's documentation!
=================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   docs/modules        

Modelo
==================
.. toctree::
   :maxdepth: 2
   :caption: Quantitativo:

   model/int     

auto
==================
.. toctree::
   :maxdepth: 2
   :caption: Documentacao:

   maths/get

   
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
