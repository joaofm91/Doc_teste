maths package
=============

Submodules
----------

maths.add module
----------------

.. automodule:: maths.add
   :members:
   :undoc-members:
   :show-inheritance:

maths.divide module
-------------------

.. automodule:: maths.divide
   :members:
   :undoc-members:
   :show-inheritance:

maths.multiply module
---------------------

.. automodule:: maths.multiply
   :members:
   :undoc-members:
   :show-inheritance:

maths.subtract module
---------------------

.. automodule:: maths.subtract
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: maths
   :members:
   :undoc-members:
   :show-inheritance:
