
Welcome to Teste's documentation!
=================================

**Inferência estatística**: É o estudo de técnicas que possibilitam a extrapolação, a um grande conjunto de dados, denominado `população`, obtidos a partir de um conjunto extraido sobre esta denominada `amostra`.

.. image:: https://drive.google.com/uc?export=view&id=1GM_5x7eu3s1Ux5P70NkLl-SEnivA1GaK

.. image:: ../images/assimetria.png


.. math:: \psi(r) = e^{-2r}